var searchData=
[
  ['new_5ftype',['new_type',['../classoctet_1_1resources_1_1resource.html#ac89fc1a07cf154fc92b173d77c9010a8',1,'octet::resources::resource']]],
  ['nifti_5fdecoder',['nifti_decoder',['../classoctet_1_1loaders_1_1nifti__decoder.html',1,'octet::loaders']]],
  ['normalize_5f3x3',['normalize_3x3',['../classoctet_1_1math_1_1mat4t.html#aa585a4911f0fe5c07f0612adc378032f',1,'octet::math::mat4t']]]
];
