var searchData=
[
  ['nifti_5fdecoder',['nifti_decoder',['../classoctet_1_1loaders_1_1nifti__decoder.html',1,'octet::loaders']]]
];
