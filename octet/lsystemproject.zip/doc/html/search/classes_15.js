var searchData=
[
  ['xml_5fwriter',['xml_writer',['../classoctet_1_1resources_1_1xml__writer.html',1,'octet::resources']]]
];
